<!-- Footer -->
<!-- <footer class="page-footer font-small blue"> -->
<footer class="cst-footer" style="">
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <!-- <a href="https://mdbootstrap.com/"> MDBootstrap.com</a> -->
    <a href="https://www.facebook.com/currentrms" target="_blank">
            <img src="https://raw.githubusercontent.com/rohitink/sociocons/master/Sociocons/facebook-sociocon.png" style="max-height: 32px;" alt="Facebook">
        </a>
        <a href="https://twitter.com/currentrms" target="_blank">
            <img src="https://raw.githubusercontent.com/rohitink/sociocons/master/Sociocons/twitter-sociocon.png" style="max-height: 32px;" alt="Twitter">
        </a>
        <a href="https://www.youtube.com/channel/UCtr9hX3v4gp_rZ7RonxG7hA" target="_blank">
            <img src="https://raw.githubusercontent.com/rohitink/sociocons/master/Sociocons/youtube-sociocon.png" style="max-height: 32px;" alt="YouTube">
        </a>
        <a href="https://in.linkedin.com/" target="_blank">
            <img src="https://raw.githubusercontent.com/rohitink/sociocons/master/Sociocons/linkedin-sociocon.png" style="max-height: 32px;" alt="YouTube">
        </a>
        <a href="https://gmail.com/" target="_blank">
            <img src="https://raw.githubusercontent.com/rohitink/sociocons/master/Sociocons/email-sociocon.png" style="max-height: 32px;" alt="YouTube">
        </a>
        <a href="https://iocl.com/" target="_blank">
            <img src="iocl.png" style="max-height: 32px;">
        </a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->